<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Registration</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>

			
<?php 
if(isset($_POST['submit'])){
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$dob = $_POST['dob'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$phone2 = $_POST['phone2'];
$address = $_POST['address'];
$college = $_POST['college'];
$course = $_POST['course'];
$year = $_POST['year'];
$branch = $_POST['branch'];
$linkedin = $_POST['linkedin'];
$fb = $_POST['fb'];
$insta = $_POST['insta'];
$question = $_POST['question'];

$db_user="id13573102_deep";
$db_pass="";
$db_name="id13573102_registration";
$db = new PDO('mysql:host=localhost;dbname=' .$db_name. ';charset=utf8',$db_user,$db_pass);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$data = $db->prepare("insert into registration(firstname, lastname, dob, email, phone, phone2, address, 
                                               college, course, year, branch, linkedin, fb, insta, question) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
$result = $data->execute([$first_name, $last_name, $dob, $email, $phone, $phone2, 
$address, $college, $course, $year, $branch, $linkedin, $fb, $insta]);
if($result){header("Location: index.html");exit;}
}
?> 





		<div class="wrapper">
			<div class="inner">
				<form action="contac.php" method="POST">
					<h3>Contact Us</h3>
					<p>Register Here</p>
					<label class="form-group">
						<input type="text" class="form-control" name="first_name" required>
						<span>First Name</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" class="form-control" name="last_name"  required>
						<span>Last Name</span>
						<span class="border"></span>
					</label>
					<label class="form-group border" style="color: #0d99d7;">Date of Birth
						<input type="date" class="form-control" name="dob" required>
					</label>
					<label class="form-group">
						<input type="email" class="form-control" name="email"  required>
						<span for="">Email</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="tel" id="phone"class="form-control" name="phone" required>
						<span>Contact Number</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="tel" class="form-control" name="phone2">
						<span>Alternative Number</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" class="form-control" name="address" required>
						<span>Address</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" class="form-control" name="college" required>
						<span>College Name</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" class="form-control" name="course" required>
						<span>Course</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<select class="form-control" name="year" style="background-color: navy;" id="year1" name="year" required>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">2</option>
							<option value="4">4</option>
							<option value="5">5</option>
						  </select>
						<span>Year</span>
						<span class="border"></span>
				
					</label>
					<label class="form-group">
						<select class="form-control" name="branch" style="background-color: navy;" id="branch1" name="branch" required>
							<option   value="cse"> Computer Science Engineering </option>
							<option   value="it"> Information Technology </option>
							  <option   value="ec"> Electronics and communication </option>
							  <option   value="ee"> Electrical Engineering </option>
							  <option   value="ce"> Civil Engineering </option>
								<option   value="me"> Mechanical Engineering </option>
								<option   value="che"> Chemical Engineering </option>
								<option   value="auto"> Automobile Engineering </option>
								  <option  value="pct"> PCT</option>
								</select>
						<span>Branch</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" class="form-control" name="linkedin" >
						<span>LinkedIn handle (Optional)</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" class="form-control" name="fb" >
						<span>Facebook handle (Optional)</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" class="form-control" name="insta">
						<span>Instagram handle (Optional)</span>
						<span class="border"></span>
					</label>


					<label class="form-group" >
						<textarea name="" id="" class="form-control" required name="question"></textarea>
						<span for="">Your Question</span>
						<span class="border"></span>
					</label>
					<button type="submit" name="submit">Submit 
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
				</form>
			</div>
		</div>
		
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>